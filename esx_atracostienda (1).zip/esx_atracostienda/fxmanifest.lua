fx_version 'adamant'

game 'gta5'

author 'Ader#6971 & Unknown'
description 'NPC Atracos de tienda fixed by Ader#6971'
version '1.2.6'

client_scripts {
	'config.lua',
    'client.lua'
}

server_scripts {
    'config.lua',
	'server.lua'
}
